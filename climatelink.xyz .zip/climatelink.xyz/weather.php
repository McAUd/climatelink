<?php

if (isset($_GET['city'])) {
    $city = $_GET['city'];
    $apiKey = '2f745fa85d563da5adb87b6cd4b81caf';
    $url = "https://api.openweathermap.org/data/2.5/weather?q={$city}&appid={$apiKey}&units=metric";
        
        
        
    // Initialize cURL session
    $ch = curl_init();

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    // Optional: If your server requires a proxy, set it here
    // curl_setopt($ch, CURLOPT_PROXY, 'http://your-proxy-server:proxy-port');

    // Execute cURL request and fetch response
    $response = curl_exec($ch);

    // Check for cURL errors
    if(curl_errno($ch)) {
        $error_msg = curl_error($ch);
    }

    // Close cURL session
    curl_close($ch);

    // Set header for JSON response
    header('Content-Type: application/json');

    // Check if there was a cURL error
    if (isset($error_msg)) {
        // Return an error response
        echo json_encode(['error' => 'Error fetching data from API: ' . $error_msg]);
    } else {
        // Decode the response to check for API errors
        $decoded_response = json_decode($response, true);

        // Check for API errors
        if (isset($decoded_response['cod']) && $decoded_response['cod'] != 200) {
            echo json_encode(['error' => 'Error from API: ' . $decoded_response['message']]);
        } else {
            // Return the API response
            echo $response;
        }
    }
} else {
    echo json_encode(['error' => 'City not provided']);
}
?>
