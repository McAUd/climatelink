window.onload = function() {
    var modal = document.getElementById("messageModal");
    var span = document.getElementsByClassName("close")[0];
    var messageText = document.getElementById("messageText");

    // Function to show modal with message
    function showMessage(message) {
        messageText.innerText = message;
        modal.style.display = "block";
    }

    // Check for messages in the URL query string
    var urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('success')) {
        showMessage(urlParams.get('success'));
    } else if (urlParams.has('error')) {
        showMessage(urlParams.get('error'));
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
};
