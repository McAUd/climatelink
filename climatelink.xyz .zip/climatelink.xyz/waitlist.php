<?php
// Database connection settings
$host = 'fdb1034.atspace.me';
$username = '4480058_base';
$password = 'jsEKy4aKT7wjudk';
$database = '4480058_base';

// Establish a connection to the database using mysqli
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!empty($_POST['email'])) {
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Check if the email already exists
            $stmt = $conn->prepare("SELECT email FROM waitlist WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows == 0) {
                // Email does not exist, insert new email
                $stmt->close();
                $stmt = $conn->prepare("INSERT INTO waitlist (email) VALUES (?)");
                $stmt->bind_param("s", $email);
                if ($stmt->execute()) {
                    $success = "Great your added to the  waitlist!";
                } else {
                    $error = "Error: " . $stmt->error;
                }
                $stmt->close();
            } else {
                $error = "Email already exists on the waitlist.";
                $stmt->close();
            }
        } else {
            $error = "Invalid email format";
        }
    } else {
        $error = "Email field is required";
    }

   // Redirect with a success or error message
$location = 'Location: index'; // Ensure this is the correct file and path
if (isset($success)) {
    $location .= '?success=' . $success;
} elseif (isset($error)) {
    $location .= '?error=' . $error;
}
header($location);
exit;

}
$conn->close();
?>
