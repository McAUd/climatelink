<?php
$api_key = getenv('34b9a84fd6f7f98ebefd3f389438d7ff');
if (!$api_key) {
    http_response_code(500);
    echo json_encode(['error' => 'API key not set']);
    exit;
}

$city = $_GET['city'] ?? '';
if (!$city) {
    http_response_code(400);
    echo json_encode(['error' => 'City name required']);
    exit;
}

$city = filter_var($city, FILTER_SANITIZE_STRING);
$url = "https://api.openweathermap.org/data/2.5/weather?q=" . urlencode($city) . "&appid=$api_key&units=metric";
$response = file_get_contents($url);
if (!$response) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to fetch weather data']);
    exit;
}

$data = json_decode($response, true);
if ($data['cod'] != 200) {
    http_response_code(404);
    echo json_encode(['error' => $data['message'] ?? 'City not found']);
    exit;
}

// Extract weather data
$weather_data = [
    'name' => $data['name'],
    'country' => $data['sys']['country'],
    'weather_main' => $data['weather'][0]['main'],
    'weather_description' => $data['weather'][0]['description'],
    'icon' => $data['weather'][0]['icon'],
    'temp' => $data['main']['temp'],
    'humidity' => $data['main']['humidity'],
    'pressure' => $data['main']['pressure'],
    'wind_speed' => $data['wind']['speed']
];

// Call tempMessage.php for advice
$params = [
    'temp' => $weather_data['temp'],
    'country' => $weather_data['country'],
    'pressure' => $weather_data['pressure'],
    'wind_speed' => $weather_data['wind_speed'],
    'humidity' => $weather_data['humidity']
];
$post_data = http_build_query($params);

$ch = curl_init('tempMessage.php');
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$advice = curl_exec($ch);
curl_close($ch);

if (!$advice) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to fetch climate advice']);
    exit;
}

$response_data = array_merge($weather_data, ['advice' => $advice]);
echo json_encode($response_data);