const show = document.getElementById("show");
const form = document.getElementById("searchForm");
const cityVal = document.getElementById("city");
const historyDiv = document.getElementById("history");
const themeToggle = document.getElementById("themeToggle");
const themeIcon = themeToggle.querySelector(".theme-icon");
const clearHistoryBtn = document.getElementById("clearHistory");
const key = "34b9a84fd6f7f98ebefd3f389438d7ff";

// Persistent History
function loadHistory() {
    const history = JSON.parse(localStorage.getItem("climateLinkHistory") || "[]");
    historyDiv.innerHTML = history
        .map(city => `<p onclick="cityVal.value='${city}';getWeather(event)">${city}</p>`)
        .join("");
}

function saveHistory(city) {
    let history = JSON.parse(localStorage.getItem("climateLinkHistory") || "[]");
    if (!history.includes(city)) {
        history.unshift(city);
        history = history.slice(0, 5); // Limit to 5 recent searches
        localStorage.setItem("climateLinkHistory", JSON.stringify(history));
    }
    loadHistory();
}

function clearHistory() {
    localStorage.removeItem("climateLinkHistory");
    loadHistory(); // Refresh UI to show empty history
}

// Dark Mode
function toggleDarkMode() {
    document.body.classList.toggle("dark-mode");
    const isDark = document.body.classList.contains("dark-mode");
    localStorage.setItem("climateLinkTheme", isDark ? "dark" : "light");
    themeIcon.setAttribute("name", isDark ? "moon-outline" : "sunny-outline");
}

function loadTheme() {
    const savedTheme = localStorage.getItem("climateLinkTheme");
    if (savedTheme === "dark" || (!savedTheme && window.matchMedia("(prefers-color-scheme: dark)").matches)) {
        document.body.classList.add("dark-mode");
        themeIcon.setAttribute("name", "moon-outline");
    } else {
        themeIcon.setAttribute("name", "sunny-outline");
    }
}

// Weather Fetching
async function getWeather(event) {
    event.preventDefault();
    const cityValue = cityVal.value.trim();
    if (!cityValue) {
        show.innerHTML = `<h3 class="error">Please enter a city name</h3>`;
        return;
    }

    try {
        const url = `https://api.openweathermap.org/data/2.5/weather?q=${cityValue}&appid=${key}&units=metric`;
        const resp = await fetch(url);
        const data = await resp.json();

        if (data.cod !== 200) {
            throw new Error(data.message || "City not found");
        }

        const tempMessage = await fetchTempMessage(
            data.main.temp,
            data.sys.country,
            data.main.pressure,
            data.wind.speed,
            data.main.humidity
        );

        show.innerHTML = `
            <div class="weather-info">
                <h2>${data.name}, ${data.sys.country}</h2>
                <h4 class="weather">${data.weather[0].main}</h4>
                <h4 class="desc">${data.weather[0].description}</h4>
                <img src="https://openweathermap.org/img/w/${data.weather[0].icon}.png" alt="Weather Icon">
                <h1>${data.main.temp} °C</h1>
                <div class="humidity">Humidity: ${data.main.humidity}%</div>
                <div class="pressure">Pressure: ${data.main.pressure} hPa</div>
                <div class="wind-speed">Wind Speed: ${data.wind.speed} m/s</div>
            </div>
            <div class="climate-advice">
                <h3>Climate Action Insights</h3>
                <div id="adviceText"></div>
            </div>
        `;
        typeText('adviceText', tempMessage);
        saveHistory(data.name);
        cityVal.value = "";
    } catch (error) {
        show.innerHTML = `<h3 class="error">${error.message}</h3>`;
        console.error("Error:", error);
    }
}

async function fetchTempMessage(temp, country, pressure, wind_speed, humidity) {
    const response = await fetch('tempMessage.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `temp=${encodeURIComponent(temp)}&country=${encodeURIComponent(country)}&pressure=${encodeURIComponent(pressure)}&wind_speed=${encodeURIComponent(wind_speed)}&humidity=${encodeURIComponent(humidity)}`
    });
    const text = await response.text();
    return text.replace(/<[^>]*>?/gm, '').trim();
}

function typeText(elementId, text) {
    let i = 0;
    const element = document.getElementById(elementId);
    element.innerHTML = "";
    const typing = setInterval(() => {
        if (i < text.length) {
            element.innerHTML += text.charAt(i);
            i++;
        } else {
            clearInterval(typing);
        }
    }, 30);
}

// Event Listeners
form.addEventListener("submit", getWeather);
themeToggle.addEventListener("click", toggleDarkMode);
clearHistoryBtn.addEventListener("click", clearHistory);

// Initial Load
loadHistory();
loadTheme();