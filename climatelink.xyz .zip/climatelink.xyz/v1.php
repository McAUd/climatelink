<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>climateLink - Climate Insights</title>
    <link rel="stylesheet" href="style.css">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">
    <meta name="theme-color" content="#ffffff">
</head>
<body>
    <div class="header">
        <div class="demo-label">Demo v1.2</div>
        <button id="themeToggle" class="theme-toggle">
            <ion-icon name="sunny-outline" class="theme-icon"></ion-icon>
        </button>
    </div>
    <div class="container">
        <h1 class="title">climateLink</h1>
        <p class="subtitle">Actionable Climate Insights</p>
        <form id="searchForm" class="search-box">
            <input type="text" placeholder="Enter a city name" id="city" autocomplete="off" required/>
            <button type="submit"><ion-icon class="search-icon" name="search-outline"></ion-icon></button>
        </form>
        <div id="history" class="history"></div>
        <button id="clearHistory" class="clear-history">Clear History</button>
        <div id="show" class="results"></div>
    </div>

    <script src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js" type="module"></script>
    <script src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js" nomodule></script>
    <script src="assets/script.js"></script>
</body>
</html>