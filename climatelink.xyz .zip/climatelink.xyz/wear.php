<?php
// PHP logic for weather insights
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['temp'])) {
    header("Content-Type: application/json");

    // Sanitize and validate inputs
    $temp = floatval($_POST['temp'] ?? 0);
    $country = htmlspecialchars($_POST['country'] ?? "Unknown", ENT_QUOTES, 'UTF-8');
    $pressure = floatval($_POST['pressure'] ?? 1013);
    $wind_speed = floatval($_POST['wind_speed'] ?? 0);
    $humidity = floatval($_POST['humidity'] ?? 50);

    // Structured insights array with deeper content
    $insights = [
        'below_0' => [
            'climate' => [
                "Extreme cold significantly increases energy consumption for heating. Enhance building insulation with materials like fiberglass batts or spray foam, and install double-glazed windows to reduce heat loss by up to 50%. Consider integrating a renewable energy source, such as a geothermal heat pump, to lower reliance on fossil fuels and cut emissions during prolonged freezes.",
                "Frost and snow risks are high in these conditions. Protect infrastructure by sealing drafts around doors and windows with weatherstripping, and support community efforts to transition to wind or solar power to ensure a stable, eco-friendly energy supply during harsh winters."
            ],
            'clothing' => [
                "✓ Base layer: Thermal underwear (merino wool or synthetic) to wick moisture and retain heat. ✓ Mid-layer: Insulating fleece or down jacket for core warmth. ✓ Outer layer: Waterproof, windproof parka with a hood to shield against snow and ice. ✓ Accessories: Wool hat, insulated gloves, scarf, and waterproof boots with thermal socks.",
                "✓ Base layer: Moisture-wicking long johns to stay dry. ✓ Mid-layer: Thick sweater or puffer vest for added insulation. ✓ Outer layer: Heavy coat with a windproof membrane. ✓ Accessories: Balaclava, mittens, and snow-ready boots with grippy soles."
            ]
        ],
        '0_10' => [
            'climate' => [
                "Cold temperatures elevate heating demands, straining energy grids. Retrofit homes with high-efficiency insulation (e.g., cellulose or rigid foam panels) to minimize heat loss, and pair this with a programmable thermostat to optimize energy use. Advocate for local renewable energy projects, such as small-scale hydroelectric systems, to diversify power sources.",
                "Frost potential requires proactive measures. Insulate exposed pipes to prevent freezing, and promote urban tree planting with cold-hardy species like evergreens to act as windbreaks, reducing heat loss from buildings and stabilizing soil in residential areas."
            ],
            'clothing' => [
                "✓ Base layer: Long-sleeve thermal shirt and pants for warmth. ✓ Mid-layer: Wool sweater or fleece pullover to trap heat. ✓ Outer layer: Quilted jacket with wind resistance. ✓ Accessories: Lightweight scarf, gloves, and ankle boots with wool socks.",
                "✓ Base layer: Breathable long underwear to regulate temperature. ✓ Mid-layer: Knit cardigan or insulated vest. ✓ Outer layer: Water-resistant coat for damp conditions. ✓ Accessories: Beanie, fingerless gloves, and sturdy shoes."
            ]
        ],
        '10_15' => [
            'climate' => [
                "Cool weather offers an opportunity for sustainable mobility. Reduce vehicle emissions by adopting electric bikes or carpooling, cutting transport-related CO2 by up to 20% per trip. Install solar water heaters to leverage milder sunlight, reducing household energy costs sustainably.",
                "Soil stabilization is key in these conditions. Plant native grasses or shrubs to prevent erosion and enhance carbon sequestration, while supporting municipal policies for green corridors that connect urban parks, boosting biodiversity and air quality."
            ],
            'clothing' => [
                "✓ Base layer: Long-sleeve cotton or bamboo shirt for comfort. ✓ Mid-layer: Lightweight sweater or softshell jacket. ✓ Outer layer: Windbreaker if breezy. ✓ Accessories: Optional thin cap or scarf, plus casual sneakers.",
                "✓ Base layer: Breathable t-shirt with long sleeves. ✓ Mid-layer: Fleece-lined hoodie or blazer. ✓ Outer layer: Light rain jacket for versatility. ✓ Accessories: Minimalist gloves and comfy loafers."
            ]
        ],
        '15_20' => [
            'climate' => [
                "Mild temperatures support water conservation efforts. Install rain gardens or permeable paving to capture runoff, reducing urban flooding risks by up to 30%. Pair this with low-flow fixtures indoors to cut water use, aligning with sustainable living goals.",
                "This weather is ideal for ecological enhancement. Establish community composting programs to recycle organic waste into soil amendments, and push for city-wide tree planting initiatives with species like maples or oaks to provide shade and sequester carbon effectively."
            ],
            'clothing' => [
                "✓ Base layer: Short-sleeve cotton tee or polo for breathability. ✓ Mid-layer: Light cardigan or denim jacket for layering. ✓ Outer layer: Optional thin raincoat. ✓ Accessories: Sneakers and a baseball cap if sunny.",
                "✓ Base layer: Lightweight long-sleeve shirt. ✓ Mid-layer: Casual hoodie or vest. ✓ Outer layer: Breathable windbreaker for slight chills. ✓ Accessories: Slip-on shoes and sunglasses."
            ]
        ],
        '20_25' => [
            'climate' => [
                "Warm weather reduces heating needs, making it ideal for passive cooling. Use cross-ventilation by opening windows strategically at night, and install exterior blinds or reflective window films to block solar heat gain, lowering indoor temperatures by up to 5°C without AC.",
                "Solar energy potential peaks in these conditions. Deploy rooftop solar panels to offset electricity use, potentially generating surplus power for the grid. Support local efforts to transition public buildings to renewable energy, amplifying community-wide impact."
            ],
            'clothing' => [
                "✓ Base layer: Loose cotton t-shirt or tank top. ✓ Mid-layer: Optional linen overshirt for style. ✓ Outer layer: Rarely needed—light shawl if cool evenings. ✓ Accessories: Sandals, wide-brimmed hat, and UV sunglasses.",
                "✓ Base layer: Breathable short-sleeve top. ✓ Mid-layer: Thin button-up shirt in natural fibers. ✓ Outer layer: Minimal jacket for breezes. ✓ Accessories: Flip-flops and a lightweight cap."
            ]
        ],
        '25_30' => [
            'climate' => [
                "Rising temperatures stress water resources. Implement xeriscaping with native, drought-resistant plants like lavender or agave to reduce irrigation needs by 50–75%. Use smart irrigation controllers to optimize watering schedules based on weather data.",
                "Energy demand climbs in warm climates. Retrofit buildings with cool roofs (reflective coatings) to lower surface temperatures by up to 20°C, and advocate for solar-powered microgrids to ensure reliable, clean energy during peak heat periods."
            ],
            'clothing' => [
                "✓ Base layer: Sleeveless top or moisture-wicking tee. ✓ Mid-layer: Loose linen shirt for airflow. ✓ Outer layer: Not required—focus on sun protection. ✓ Accessories: Straw hat, flip-flops, and polarized sunglasses.",
                "✓ Base layer: Lightweight tank or short-sleeve athletic shirt. ✓ Mid-layer: Open weave cover-up for shade. ✓ Outer layer: None needed. ✓ Accessories: Sandals, visor, and a reusable water bottle."
            ]
        ],
        '30_35' => [
            'climate' => [
                "Hot weather challenges agriculture and human comfort. Cultivate heat-tolerant crops like sorghum or millet, and use mulch to retain soil moisture, reducing evaporation by up to 70%. Install ceiling fans to improve air circulation indoors sustainably.",
                "Urban heat islands intensify in these conditions. Expand green spaces with shade trees like eucalyptus or palms to lower local temperatures by 2–5°C, and promote electric vehicle adoption to cut transport emissions during high-energy summer months."
            ],
            'clothing' => [
                "✓ Base layer: Loose-fitting cotton shirt or tank. ✓ Mid-layer: Optional thin long-sleeve for sun protection. ✓ Outer layer: None—prioritize ventilation. ✓ Accessories: Wide-brimmed hat, sandals, and SPF 50 sunscreen.",
                "✓ Base layer: Breathable athletic wear or tunic. ✓ Mid-layer: UV-protective rash guard if outdoors long. ✓ Outer layer: Avoid heavy layers. ✓ Accessories: Cooling towel, flip-flops, and a hydration pack."
            ]
        ],
        '35_40' => [
            'climate' => [
                "Very hot conditions demand heat mitigation. Develop urban green roofs with sedums or grasses to reduce building heat absorption by 30–50%, and install solar-powered misting systems in public areas to provide relief without grid strain.",
                "Energy efficiency is critical as AC use spikes. Upgrade to appliances with high SEER ratings (e.g., 16+), and retrofit lighting with LEDs to cut power use by 75% compared to incandescents, easing pressure on energy infrastructure."
            ],
            'clothing' => [
                "✓ Base layer: Ultra-light tank or moisture-wicking shirt. ✓ Mid-layer: Long-sleeve UV shirt for sun safety. ✓ Outer layer: None—keep it minimal. ✓ Accessories: Bucket hat, ventilated sandals, and high-SPF sunscreen.",
                "✓ Base layer: Thin, loose-fitting top in light colors. ✓ Mid-layer: Optional rash guard with UPF 50+. ✓ Outer layer: Avoid excess layers. ✓ Accessories: Cooling neck wrap, open-toe shoes, and shades."
            ]
        ],
        'above_40' => [
            'climate' => [
                "Extreme heat poses health and environmental risks. Establish solar-powered cooling centers in community hubs to reduce heat-related illnesses, and plant heat-tolerant trees like acacias to create microclimates that lower ambient temperatures by up to 7°C.",
                "Water scarcity worsens in these conditions. Deploy rainwater harvesting systems with storage tanks to capture scarce precipitation, and push for policies incentivizing greywater recycling to sustain urban water supplies during prolonged heatwaves."
            ],
            'clothing' => [
                "✓ Base layer: Minimal singlet or breathable tee in white. ✓ Mid-layer: Long-sleeve UV-blocking shirt for protection. ✓ Outer layer: None—stay light. ✓ Accessories: Wide visor, lightweight sandals, and SPF lip balm.",
                "✓ Base layer: Ultra-thin moisture-wicking top. ✓ Mid-layer: UPF 50+ long-sleeve cover for sun. ✓ Outer layer: Avoid entirely. ✓ Accessories: Cooling bandana, slip-ons, and a portable fan."
            ]
        ]
    ];

    // Determine temperature range
    $key = match (true) {
        $temp < 0 => 'below_0',
        $temp < 10 => '0_10',
        $temp < 15 => '10_15',
        $temp < 20 => '15_20',
        $temp < 25 => '20_25',
        $temp < 30 => '25_30',
        $temp < 35 => '30_35',
        $temp < 40 => '35_40',
        default => 'above_40'
    };

    // Base messages
    $climate = [$insights[$key]['climate'][array_rand($insights[$key]['climate'])]];
    $clothing = [$insights[$key]['clothing'][array_rand($insights[$key]['clothing'])]];
    
    // Additional conditions for depth
    if ($temp > 30 && $humidity > 70) {
        $climate[] = "High heat and humidity amplify discomfort and energy use. Install high-efficiency dehumidifiers to maintain indoor air quality, and use ceiling fans to enhance airflow, reducing reliance on air conditioning by up to 15%.";
        $clothing[] = "✓ Add moisture-wicking fabrics like bamboo or polyester blends to manage sweat effectively.";
    }
    if ($pressure < 1000) {
        $climate[] = "Low pressure indicates approaching storms. Reinforce windows with storm shutters and elevate outdoor equipment to prevent flood damage, while monitoring real-time weather data for preparedness.";
        $clothing[] = "✓ Include a compact, breathable raincoat and waterproof footwear for sudden rain.";
    } elseif ($pressure > 1020) {
        $climate[] = "High pressure ensures stable, clear weather. Maximize solar panel efficiency by cleaning panels to boost output by 5–10%, and plan outdoor activities to leverage the calm conditions.";
        $clothing[] = "✓ Focus on lightweight, sun-protective clothing—no rain gear required.";
    }
    if ($wind_speed > 10) {
        $climate[] = "Strong winds heighten wildfire risks and energy loss. Anchor outdoor furniture and install wind turbines where feasible to harness gusts, offsetting power needs with renewable energy.";
        $clothing[] = "✓ Layer with a windproof jacket or vest to block gusts and maintain warmth.";
    } elseif ($wind_speed < 2) {
        $climate[] = "Calm winds create ideal conditions for low-impact travel. Opt for walking or cycling to reduce emissions by up to 1 kg CO2 per 5 km, and ventilate homes naturally to improve air quality.";
        $clothing[] = "✓ Stick to breathable layers—wind protection is unnecessary.";
    }
    if ($humidity > 70 && $temp <= 30) {
        $climate[] = "High humidity promotes mold growth and discomfort. Use silica gel packs or dehumidifiers in enclosed spaces to keep moisture below 60%, and ventilate rooms during cooler hours to refresh air.";
        $clothing[] = "✓ Opt for quick-dry fabrics like nylon or microfiber to stay comfortable.";
    } elseif ($humidity < 30) {
        $climate[] = "Low humidity dries out soil and skin. Apply organic mulch to garden beds to retain moisture, and use drip irrigation to deliver water efficiently, saving up to 50% compared to sprinklers.";
        $clothing[] = "✓ Wear soft, breathable fabrics—no adjustments needed for humidity.";
    }

    // Country-specific recommendations
    $countryTips = [
        'US' => "Participate in state-level climate action plans, such as adopting net-zero building codes or expanding EV charging networks, to drive systemic change.",
        'GB' => "Support offshore wind farms by backing policies for increased turbine installations, aiming to generate 40 GW by 2030 and bolster clean energy.",
        'AU' => "Adopt water-saving technologies like greywater recycling systems in arid regions, targeting a 30% reduction in household water use.",
        'IN' => "Expand rural solar microgrids to provide clean energy to off-grid areas, aiming to power 10 million homes sustainably by 2030."
    ];
    if (isset($countryTips[$country])) {
        $climate[] = $countryTips[$country];
    }

    echo json_encode([
        "climate" => implode(" ", $climate),
        "clothing" => implode(" ", $clothing)
    ]);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>climateLink - Climate Insights</title>
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">
    <meta name="theme-color" content="#ffffff">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap');

        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Roboto', sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, #ffffff, #f0f2f5);
            display: flex;
            justify-content: center;
            align-items: center;
            color: #333;
            padding: 15px;
        }
        body.dark-mode { background: linear-gradient(135deg, #1a1a1a, #2c3e50); color: #e0e0e0; }

        .header {
            position: fixed;
            top: 10px;
            left: 10px;
            right: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 5px;
        }
        .demo-label {
            background: #27ae60;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 700;
            color: #fff;
        }
        .theme-toggle {
            background: #3498db;
            border: none;
            padding: 6px;
            border-radius: 50%;
            cursor: pointer;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s ease;
        }
        .theme-toggle:hover { background: #2980b9; }
        .theme-icon { font-size: 1.1rem; color: #fff; }

        .container {
            width: 100%;
            max-width: 600px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-top: 60px;
        }
        body.dark-mode .container { background: #2c2c2c; box-shadow: 0 5px 15px rgba(0,0,0,0.3); }

        .title { font-size: 1.8rem; font-weight: 700; color: #27ae60; margin-bottom: 5px; }
        .subtitle { font-size: 0.9rem; color: #666; margin-bottom: 15px; }
        body.dark-mode .subtitle { color: #b0b0b0; }

        .search_box {
            display: flex;
            gap: 8px;
            margin-bottom: 15px;
        }
        .search_box input {
            flex: 1;
            padding: 10px 15px;
            border: none;
            border-radius: 20px;
            font-size: 0.9rem;
            background: rgba(0,0,0,0.05);
            color: #333;
            outline: none;
            transition: background 0.3s ease;
        }
        body.dark-mode .search_box input { background: rgba(255,255,255,0.1); color: #e0e0e0; }
        .search_box input:focus { background: rgba(0,0,0,0.1); }
        .search_box button {
            background: #27ae60;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        .search_box button:hover { background: #219653; }
        .icon { font-size: 1.4rem; color: #fff; }

        .history { margin-bottom: 10px; }
        .history p {
            padding: 6px 10px;
            background: rgba(0,0,0,0.05);
            border-radius: 15px;
            margin: 5px 0;
            cursor: pointer;
            font-size: 0.85rem;
        }
        body.dark-mode .history p { background: #3c3c3c; }
        .history p:hover { background: rgba(0,0,0,0.1); }
        .clear-history {
            background: #e74c3c;
            color: #fff;
            border: none;
            padding: 6px 12px;
            border-radius: 15px;
            font-size: 0.8rem;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        .clear-history:hover { background: #c0392b; }

        .results { font-size: 0.9rem; line-height: 1.6; }
        .weather-info {
            background: rgba(0,0,0,0.05);
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 10px;
        }
        body.dark-mode .weather-info { background: #3c3c3c; }
        .weather-info h2 { font-size: 1.4rem; color: #27ae60; margin-bottom: 5px; }
        .weather-info h4 { font-size: 0.85rem; color: #666; margin-bottom: 3px; }
        body.dark-mode .weather-info h4 { color: #b0b0b0; }
        .weather-info h1 { font-size: 1.8rem; color: #e74c3c; margin: 8px 0; }
        .weather-info img { width: 60px; margin: 5px auto; }
        .weather-info div { font-size: 0.85rem; margin: 3px 0; }

        .climate-advice { padding: 12px; background: rgba(0,0,0,0.03); border-radius: 8px; }
        body.dark-mode .climate-advice { background: #3c3c3c; }
        .selection-buttons {
            display: flex;
            gap: 8px;
            justify-content: center;
            margin-bottom: 10px;
            flex-wrap: wrap;
        }
        .climate-advice button {
            background: #3498db;
            color: #fff;
            border: none;
            padding: 6px 12px;
            border-radius: 15px;
            font-size: 0.85rem;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        .climate-advice button:hover { background: #2980b9; }
        .climate-advice button.active { background: #27ae60; }
        body.dark-mode .climate-advice button { background: #3c3c3c; }
        body.dark-mode .climate-advice button:hover { background: #4a4a4a; }
        body.dark-mode .climate-advice button.active { background: #219653; }
        .error { color: #e74c3c; font-weight: 500; font-size: 0.9rem; }

        @media (max-width: 400px) {
            .header { top: 5px; }
            .demo-label { font-size: 0.7rem; padding: 4px 8px; }
            .theme-toggle { width: 28px; height: 28px; }
            .theme-icon { font-size: 1rem; }
            .container { padding: 15px; margin-top: 50px; }
            .title { font-size: 1.5rem; }
            .subtitle { font-size: 0.8rem; }
            .search_box input { padding: 8px 12px; font-size: 0.85rem; }
            .search_box button { width: 35px; height: 35px; }
            .icon { font-size: 1.2rem; }
            .weather-info h2 { font-size: 1.2rem; }
            .weather-info h1 { font-size: 1.6rem; }
            .climate-advice button { font-size: 0.75rem; padding: 5px 10px; }
            .results { font-size: 0.85rem; }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="demo-label">Demo v1.2</div>
        <button id="themeToggle" class="theme-toggle">
            <ion-icon name="sunny-outline" class="theme-icon"></ion-icon>
        </button>
    </div>
    <div class="container">
        <h1 class="title">climateLink</h1>
        <p class="subtitle">Actionable Climate Insights</p>
        <form id="searchForm" class="search_box">
            <input type="text" placeholder="Enter a city name" id="city" autocomplete="off" required/>
            <button type="submit"><ion-icon class="icon" name="search-outline"></ion-icon></button>
        </form>
        <div id="history" class="history"></div>
        <button id="clearHistory" class="clear-history">Clear History</button>
        <div id="show" class="results"></div>
    </div>

    <script src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js" type="module"></script>
    <script src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js" nomodule></script>
    <script>
        const show = document.getElementById("show");
        const form = document.getElementById("searchForm");
        const cityVal = document.getElementById("city");
        const historyDiv = document.getElementById("history");
        const themeToggle = document.getElementById("themeToggle");
        const themeIcon = themeToggle.querySelector(".theme-icon");
        const clearHistoryBtn = document.getElementById("clearHistory");
        const key = "34b9a84fd6f7f98ebefd3f389438d7ff";

        function loadHistory() {
            const history = JSON.parse(localStorage.getItem("climateLinkHistory") || "[]");
            historyDiv.innerHTML = history.map(city => `<p onclick="cityVal.value='${city}';getWeather(event)">${city}</p>`).join("");
        }

        function saveHistory(city) {
            let history = JSON.parse(localStorage.getItem("climateLinkHistory") || "[]");
            if (!history.includes(city)) {
                history.unshift(city);
                history = history.slice(0, 5);
                localStorage.setItem("climateLinkHistory", JSON.stringify(history));
            }
            loadHistory();
        }

        function clearHistory() {
            localStorage.removeItem("climateLinkHistory");
            loadHistory();
        }

        function toggleDarkMode() {
            document.body.classList.toggle("dark-mode");
            const isDark = document.body.classList.contains("dark-mode");
            localStorage.setItem("climateLinkTheme", isDark ? "dark" : "light");
            themeIcon.setAttribute("name", isDark ? "moon-outline" : "sunny-outline");
        }

        function loadTheme() {
            const savedTheme = localStorage.getItem("climateLinkTheme");
            if (savedTheme === "dark" || (!savedTheme && window.matchMedia("(prefers-color-scheme: dark)").matches)) {
                document.body.classList.add("dark-mode");
                themeIcon.setAttribute("name", "moon-outline");
            }
        }

        async function getWeather(event) {
            event.preventDefault();
            const cityValue = cityVal.value.trim();
            if (!cityValue) {
                show.innerHTML = `<h3 class="error">Please enter a city name</h3>`;
                return;
            }

            try {
                const url = `https://api.openweathermap.org/data/2.5/weather?q=${cityValue}&appid=${key}&units=metric`;
                const resp = await fetch(url);
                const data = await resp.json();

                if (data.cod !== 200) throw new Error(data.message || "City not found");

                const { climateMessage, clothingMessage } = await fetchTempMessage(data.main.temp, data.sys.country, data.main.pressure, data.wind.speed, data.main.humidity);

                show.innerHTML = `
                    <div class="weather-info">
                        <h2>${data.name}, ${data.sys.country}</h2>
                        <h4 class="weather">${data.weather[0].main}</h4>
                        <h4 class="desc">${data.weather[0].description}</h4>
                        <img src="https://openweathermap.org/img/w/${data.weather[0].icon}.png" alt="Weather Icon">
                        <h1>${data.main.temp} °C</h1>
                        <div>Humidity: ${data.main.humidity}%</div>
                        <div>Pressure: ${data.main.pressure} hPa</div>
                        <div>Wind Speed: ${data.wind.speed} m/s</div>
                    </div>
                    <div class="climate-advice">
                        <div class="selection-buttons">
                            <button class="insight-btn active" data-type="climate">Climate Insights</button>
                            <button class="insight-btn" data-type="clothing">Clothing Recommendations</button>
                        </div>
                        <div id="adviceText"></div>
                    </div>
                `;

                typeText('adviceText', climateMessage);

                document.querySelectorAll('.insight-btn').forEach(btn => {
                    btn.addEventListener('click', () => {
                        document.querySelectorAll('.insight-btn').forEach(b => b.classList.remove('active'));
                        btn.classList.add('active');
                        typeText('adviceText', btn.dataset.type === 'climate' ? climateMessage : clothingMessage);
                    });
                });

                saveHistory(data.name);
                cityVal.value = "";
            } catch (error) {
                show.innerHTML = `<h3 class="error">${error.message}</h3>`;
                console.error("Error:", error);
            }
        }

        async function fetchTempMessage(temp, country, pressure, wind_speed, humidity) {
            const response = await fetch(window.location.href, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `temp=${encodeURIComponent(temp)}&country=${encodeURIComponent(country)}&pressure=${encodeURIComponent(pressure)}&wind_speed=${encodeURIComponent(wind_speed)}&humidity=${encodeURIComponent(humidity)}`
            });
            const data = await response.json();
            return {
                climateMessage: data.climate,
                clothingMessage: data.clothing
            };
        }

        function typeText(elementId, text) {
            let i = 0;
            const element = document.getElementById(elementId);
            element.innerHTML = "";
            const typing = setInterval(() => {
                if (i < text.length) {
                    element.innerHTML += text.charAt(i);
                    i++;
                } else {
                    clearInterval(typing);
                }
            }, 20);
        }

        form.addEventListener("submit", getWeather);
        themeToggle.addEventListener("click", toggleDarkMode);
        clearHistoryBtn.addEventListener("click", clearHistory);
        loadHistory();
        loadTheme();
    </script>
</body>
</html>