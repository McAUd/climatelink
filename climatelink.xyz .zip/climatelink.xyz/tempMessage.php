<?php
header("Content-Type: text/plain");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo "Method Not Allowed";
    exit;
}

$temp = isset($_POST['temp']) ? floatval($_POST['temp']) : null;
$country = isset($_POST['country']) ? htmlspecialchars($_POST['country'], ENT_QUOTES, 'UTF-8') : "Unknown";
$pressure = isset($_POST['pressure']) ? floatval($_POST['pressure']) : null;
$wind_speed = isset($_POST['wind_speed']) ? floatval($_POST['wind_speed']) : null;
$humidity = isset($_POST['humidity']) ? floatval($_POST['humidity']) : null;

if ($temp === null || $pressure === null || $wind_speed === null || $humidity === null) {
    http_response_code(400);
    echo "Invalid input data";
    exit;
}

$message = [];

// Temperature-based logic with randomization
$tempMessages = [
    'below_0' => ["Extremely cold with frost or snow likely", "Freezing temps—bundle up"],
    '0_10' => ["Very cold, watch for frost", "Chilly with potential ice"],
    '10_15' => ["Chilly conditions", "Cool and crisp today"],
    '15_20' => ["Mild and comfortable", "Pleasant weather today"],
    '20_25' => ["Warm and pleasant", "Nice day for outdoor time"],
    '25_30' => ["Warm, great for tropical plants", "Heating up nicely"],
    '30_35' => ["Hot, stay hydrated", "Toasty—keep cool"],
    '35_40' => ["Very hot, risk of heat exhaustion", "Scorching heat today"],
    'above_40' => ["Extremely hot, heat stroke danger", "Blazing temps—stay safe"]
];

$tempAdvice = [
    'below_0' => ["Boost insulation and switch to renewable heating", "Layer up and use eco-friendly heat"],
    '0_10' => ["Support renewable energy and insulate homes", "Stay warm sustainably"],
    '10_15' => ["Use public transit or cycle to lower emissions", "Go green with transport"],
    '15_20' => ["Plant trees and opt for eco-friendly transport", "Grow green and travel light"],
    '20_25' => ["Leverage passive cooling and solar energy", "Cool naturally and use solar"],
    '25_30' => ["Conserve water and invest in solar power", "Save water, harness the sun"],
    '30_35' => ["Grow drought-resistant plants and adopt EVs", "Plant smart and drive electric"],
    '35_40' => ["Increase urban greenery and reduce emissions", "Green cities, cut pollution"],
    'above_40' => ["Set up cooling zones and expand green spaces", "Cool off and plant more"]
];

switch (true) {
    case $temp < 0:
        $key = 'below_0';
        break;
    case $temp < 10:
        $key = '0_10';
        break;
    case $temp < 15:
        $key = '10_15';
        break;
    case $temp < 20:
        $key = '15_20';
        break;
    case $temp < 25:
        $key = '20_25';
        break;
    case $temp < 30:
        $key = '25_30';
        break;
    case $temp < 35:
        $key = '30_35';
        break;
    case $temp < 40:
        $key = '35_40';
        break;
    default:
        $key = 'above_40';
}

$message[] = $tempMessages[$key][array_rand($tempMessages[$key])] . ". " . $tempAdvice[$key][array_rand($tempAdvice[$key])] . ".";

// Combined condition: High temp + high humidity
if ($temp > 30 && $humidity > 70) {
    $message[] = "Hot and humid—tough combo! Use fans or AC sparingly and stay hydrated.";
}

// Pressure-based logic
if ($pressure < 1000) {
    $message[] = "Low pressure, expect weather shifts. Prepare for storms and monitor forecasts.";
} elseif ($pressure > 1020) {
    $message[] = "High pressure, stable weather ahead. Enjoy it while staying sustainable.";
}

// Wind speed-based logic
if ($wind_speed > 10) {
    $message[] = "Strong winds in effect. Secure outdoor items and drive carefully.";
} elseif ($wind_speed < 2) {
    $message[] = "Calm winds today. Perfect for biking or walking to cut emissions.";
}

// Humidity-based logic
if ($humidity > 70 && $temp <= 30) { // Avoid overlap with high temp combo
    $message[] = "High humidity detected. Stay hydrated and consider a dehumidifier.";
} elseif ($humidity < 30) {
    $message[] = "Low humidity levels. Hydrate and moisturize for comfort.";
}

// Country-specific tweak (simple lookup)
$countryTips = [
    'US' => "Check local climate policies",
    'GB' => "Support wind energy initiatives",
    'AU' => "Conserve water in dry regions",
    'IN' => "Promote solar in rural areas"
];
if (isset($countryTips[$country])) {
    $message[] = $countryTips[$country] . ".";
}

// Output the combined message
echo "In $country: " . implode(" ", $message);
?>